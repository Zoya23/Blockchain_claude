// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

contract DataMarketplace {

    struct Dataset {
        uint id;
        string name;
        string description;
        uint price;
        address payable owner;
        bool isAvailable;
    }

    uint public datasetCount = 0;

    mapping(uint => Dataset) public datasets;
    mapping(uint => mapping(address => bool)) public accessGranted;

    event DatasetListed(
        uint id,
        string name,
        uint price,
        address owner
    );

    event DatasetPurchased(
        uint id,
        address buyer,
        address owner,
        uint price
    );

    function listDataset(
        string memory _name,
        string memory _description,
        uint _price
    ) public {
        require(_price > 0, "Price must be greater than zero");

        datasetCount++;

        datasets[datasetCount] = Dataset(
            datasetCount,
            _name,
            _description,
            _price,
            payable(msg.sender),
            true
        );

        emit DatasetListed(
            datasetCount,
            _name,
            _price,
            msg.sender
        );
    }

    function purchaseDataset(uint _id) public payable {
        Dataset storage dataset = datasets[_id];

        require(dataset.id > 0, "Dataset does not exist");
        require(dataset.isAvailable == true, "Dataset is not available");
        require(msg.value >= dataset.price, "Insufficient payment");
        require(msg.sender != dataset.owner, "Owner cannot buy own dataset");

        dataset.owner.transfer(msg.value);

        accessGranted[_id][msg.sender] = true;

        emit DatasetPurchased(
            _id,
            msg.sender,
            dataset.owner,
            msg.value
        );
    }

    function checkAccess(uint _id, address _user) public view returns (bool) {
        return accessGranted[_id][_user];
    }
}
