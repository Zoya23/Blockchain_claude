# Practical 7 — Developing a Decentralized Marketplace for Data Exchange

## Aim
Build a Solidity smart contract where sellers can list a dataset for a price, and buyers can purchase access to it by paying ETH — all deployed to a local Ganache blockchain via Truffle.

## Project Structure
```
Practical-07-Data-Marketplace/
├── contracts/
│   └── DataMarketplace.sol
├── migrations/
│   └── 2_deploy_datamarketplace.js
├── truffle-config.js
└── console-commands.md
```

## Steps
1. Open Ganache → **Quickstart Ethereum** (RPC `http://127.0.0.1:7545`, Network ID `5777`)
2. `truffle init` in a new project folder
3. Add [`contracts/DataMarketplace.sol`](contracts/DataMarketplace.sol)
4. Configure [`truffle-config.js`](truffle-config.js)
5. Add [`migrations/2_deploy_datamarketplace.js`](migrations/2_deploy_datamarketplace.js)
6. `truffle compile`
7. `truffle migrate` (use `--reset` to redeploy)
8. `truffle console` → run the commands in [`console-commands.md`](console-commands.md)

## Contract logic
- `listDataset(name, description, price)` — seller lists a dataset; increments `datasetCount`, stores a `Dataset` struct, emits `DatasetListed`
- `purchaseDataset(id)` *(payable)* — buyer pays ≥ price; funds are forwarded to the seller, `accessGranted[id][buyer]` is set to `true`, emits `DatasetPurchased`
- `checkAccess(id, user)` — read-only check of whether a user has purchased access

### Guardrails (`require` checks)
- Price must be > 0
- Dataset must exist and be marked available
- Payment must be ≥ listed price
- Owner cannot buy their own dataset

## Code review
✅ Logic is sound and works as demonstrated in the journal. Two minor, optional improvements if you want to harden it further (not required for the exam, but worth knowing if asked):
- **No refund of overpayment** — if a buyer sends more than `price`, the extra ETH is not returned. Could add a refund of `msg.value - dataset.price`.
- **`.transfer()`** forwards a fixed 2300 gas stipend — fine for a Ganache demo with EOA sellers, but in production `.call{value: ...}("")` with a reentrancy guard is the modern recommended pattern.

Neither is a bug for this practical's purposes — the contract works correctly as-is on Ganache.
