# Truffle Console Session — Practical 7

Run `truffle console` (Ganache must already be running), then paste these one at a time.

```js
// Get the deployed contract instance
let marketplace = await DataMarketplace.deployed()

// List a dataset as the seller (accounts[0] by default)
await marketplace.listDataset(
  "Customer Purchase Dataset",
  "Dataset containing customer age, income and purchase behavior",
  web3.utils.toWei("1", "ether")
)

// Check the dataset details
let data = await marketplace.datasets(1)
data

// Get all Ganache accounts
let accounts = await web3.eth.getAccounts()

// Purchase the dataset as a different account (the buyer)
await marketplace.purchaseDataset(1, {
  from: accounts[1],
  value: web3.utils.toWei("1", "ether")
})

// Confirm the buyer now has access
let access = await marketplace.checkAccess(1, accounts[1])
access   // → true
```

Check Ganache's **Transactions** tab — you should see the `listDataset` and `purchaseDataset` transactions.
