const DataMarketplace = artifacts.require("DataMarketplace");

module.exports = function (deployer) {
  deployer.deploy(DataMarketplace);
};
