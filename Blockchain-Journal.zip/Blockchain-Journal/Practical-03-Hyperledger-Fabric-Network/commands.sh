#!/bin/bash
# Practical 3 — Configuring and Running a Hyperledger Fabric Network
# Run these commands in order, in Git Bash / WSL / Linux terminal.

# Step 1: Verify prerequisites (Docker, Docker Compose, Git, cURL, Go)
docker --version
git --version

# Step 2: Download Hyperledger Fabric samples, binaries and Docker images
# NOTE: the old bit.ly bootstrap link from the original journal is deprecated.
# Use the current official installer:
curl -sSLO https://raw.githubusercontent.com/hyperledger/fabric/main/scripts/install-fabric.sh
chmod +x install-fabric.sh
./install-fabric.sh docker samples binary

# Step 3: Open the test network folder
cd fabric-samples/test-network

# Step 4: Bring the network up (peers, ordering service, CAs)
./network.sh up

# Step 5: Create a channel (default name: mychannel)
./network.sh createChannel

# Step 6: Deploy chaincode onto the channel
./network.sh deployCC -ccn basic -ccp ../asset-transfer-basic/chaincode-go -ccl go

# Step 7: Set environment variables for Org1 (COMPLETE set — the journal's
# 2-variable version is not enough to actually run peer commands, since the
# test network has TLS enabled by default)
export PATH=${PWD}/../bin:$PATH
export FABRIC_CFG_PATH=$PWD/../config/
export CORE_PEER_TLS_ENABLED=true
export CORE_PEER_LOCALMSPID="Org1MSP"
export CORE_PEER_TLS_ROOTCERT_FILE=${PWD}/organizations/peerOrganizations/org1.example.com/peers/peer0.org1.example.com/tls/ca.crt
export CORE_PEER_MSPCONFIGPATH=${PWD}/organizations/peerOrganizations/org1.example.com/users/Admin@org1.example.com/msp
export CORE_PEER_ADDRESS=localhost:7051

# Step 8: Initialize the ledger
peer chaincode invoke -o localhost:7050 \
  --ordererTLSHostnameOverride orderer.example.com \
  --tls --cafile "${PWD}/organizations/ordererOrganizations/example.com/orderers/orderer.example.com/msp/tlscacerts/tlsca.example.com-cert.pem" \
  -C mychannel -n basic \
  --peerAddresses localhost:7051 --tlsRootCertFiles "${PWD}/organizations/peerOrganizations/org1.example.com/peers/peer0.org1.example.com/tls/ca.crt" \
  -c '{"function":"InitLedger","Args":[]}'

# Step 9: Query all assets
peer chaincode query -C mychannel -n basic -c '{"Args":["GetAllAssets"]}'

# Step 10: Add a new asset (transaction)
peer chaincode invoke -o localhost:7050 \
  --ordererTLSHostnameOverride orderer.example.com \
  --tls --cafile "${PWD}/organizations/ordererOrganizations/example.com/orderers/orderer.example.com/msp/tlscacerts/tlsca.example.com-cert.pem" \
  -C mychannel -n basic \
  --peerAddresses localhost:7051 --tlsRootCertFiles "${PWD}/organizations/peerOrganizations/org1.example.com/peers/peer0.org1.example.com/tls/ca.crt" \
  -c '{"function":"CreateAsset","Args":["asset10","red","10","Om","500"]}'

# Step 11: Verify the transaction
peer chaincode query -C mychannel -n basic -c '{"Args":["ReadAsset","asset10"]}'

# Step 12: Tear down the network
./network.sh down
