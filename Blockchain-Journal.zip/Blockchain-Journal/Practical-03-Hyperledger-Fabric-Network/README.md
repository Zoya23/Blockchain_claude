# Practical 3 — Configuring and Running a Hyperledger Fabric Network

## Aim
Install Hyperledger Fabric, bring up the sample test network, create a channel, deploy chaincode, and invoke/query it.

## Prerequisites
Docker, Docker Compose, Git, cURL, Go — verify with:
```bash
docker --version
git --version
```

## Full command sequence
See [`commands.sh`](commands.sh) for the complete, copy-pasteable script. Key stages:

1. **Install Fabric** (binaries, Docker images, samples)
2. **Start the network** — `cd fabric-samples/test-network && ./network.sh up`
3. **Create a channel** — `./network.sh createChannel` (default: `mychannel`)
4. **Deploy chaincode** — `./network.sh deployCC -ccn basic -ccp ../asset-transfer-basic/chaincode-go -ccl go`
5. **Set Org1 environment variables**
6. **Invoke `InitLedger`**, then **query `GetAllAssets`**
7. **Invoke `CreateAsset`**, then **query `ReadAsset`** to verify
8. **Tear down** — `./network.sh down`

### Expected output (query after InitLedger)
A JSON array of the sample assets seeded by `InitLedger` (asset1–asset6, each with ID/color/size/owner/value).

### Expected output (after CreateAsset + ReadAsset "asset10")
```json
{"ID":"asset10","color":"red","size":"10","owner":"Om","appraisedValue":"500"}
```

## ⚠️ Corrections made vs. the original journal
Two things in the journal, as written, will **not work** on a real Fabric test network and have been fixed in [`commands.sh`](commands.sh):

1. **Download link** — the journal uses `curl -sSL https://bit.ly/2ysbOFE | bash -s`, an old shortened bootstrap link that is no longer reliable. Replaced with the current official `install-fabric.sh` script from the Hyperledger Fabric GitHub repo.
2. **Environment variables / peer commands** — the journal only sets `CORE_PEER_LOCALMSPID` and `CORE_PEER_ADDRESS`. The Fabric test-network has **TLS enabled by default**, so `peer chaincode invoke`/`query` also need `CORE_PEER_TLS_ENABLED`, `CORE_PEER_TLS_ROOTCERT_FILE`, `CORE_PEER_MSPCONFIGPATH`, `FABRIC_CFG_PATH`, and the invoke commands need `--tls`, `--cafile`, `--peerAddresses`, and `--tlsRootCertFiles` flags — otherwise you'll get a connection/authorization error. The complete, working versions are in `commands.sh`.

If your instructor only wants the simplified commands exactly as taught in class (e.g. TLS disabled in a custom network config), keep the simpler two-line version — just be aware it assumes a non-default network setup.
