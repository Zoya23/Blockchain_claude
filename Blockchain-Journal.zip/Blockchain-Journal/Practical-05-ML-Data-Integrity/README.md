# Practical 5 — Using Blockchain to Ensure Data Integrity in ML Models

## Aim
Hash a training dataset with SHA-256, store the hash in a simple "blockchain block", train a Logistic Regression model, then re-verify the dataset's hash to detect tampering.

## Files
- [`blockchain_ml.py`](blockchain_ml.py) — main script
- [`dataset.csv`](dataset.csv) — sample dataset (Age, Salary, Purchased) — **generated for this repo**, since the journal referenced a `dataset.csv` that wasn't included. Swap in your own CSV with the same column names if you have one.

## Requirements
```bash
pip install pandas scikit-learn
```

## Run
```bash
python blockchain_ml.py
```

## What it does
1. Loads `dataset.csv` with pandas
2. Computes a SHA-256 hash of the entire dataset → stores it in a `block` dict (`index`, `data_hash`)
3. Trains a `LogisticRegression` model to predict `Purchased` from `Age` and `Salary`
4. Re-hashes the dataset and compares it to the original hash
5. Prints **"Dataset Integrity Verified"** if unchanged, or **"WARNING! Dataset Tampered"** if the data was modified after hashing

### Verified Output
```
Dataset Hash:
1ea019cea98553fa434a8aea6bf392f478b673e6ff80428983160eb4016a8974

Model Trained Successfully

Verification Hash:
1ea019cea98553fa434a8aea6bf392f478b673e6ff80428983160eb4016a8974

Dataset Integrity Verified
```

✅ Ran end-to-end and verified working with the included `dataset.csv` — no code changes were needed, the logic in the journal was correct.

### To test the tampering path
Edit any single value in `dataset.csv` between the two hash computations (or reload a modified copy before Step 7) — the hashes will differ and it will print `WARNING! Dataset Tampered` instead.
