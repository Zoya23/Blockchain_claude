import pandas as pd
import hashlib
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression

# Step 3 - Load Dataset
df = pd.read_csv("dataset.csv")
print(df)

# Step 4 - Generate Dataset Hash
dataset_string = df.to_string()
hash_value = hashlib.sha256(dataset_string.encode()).hexdigest()

print("Dataset Hash:")
print(hash_value)

# Step 5 - Create Simple Blockchain
blockchain = []

block = {
    "index": 1,
    "data_hash": hash_value
}

blockchain.append(block)

print("\nBlockchain Block:")
print(blockchain)

# Step 6 - Train ML Model
X = df[['Age', 'Salary']]
y = df['Purchased']

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

model = LogisticRegression()
model.fit(X_train, y_train)

print("\nModel Trained Successfully")

# Step 7 - Verify Dataset Integrity
new_dataset_string = df.to_string()
new_hash = hashlib.sha256(new_dataset_string.encode()).hexdigest()

print("\nVerification Hash:")
print(new_hash)

# Step 8 - Compare Hashes
if hash_value == new_hash:
    print("\nDataset Integrity Verified")
else:
    print("\nWARNING! Dataset Tampered")
