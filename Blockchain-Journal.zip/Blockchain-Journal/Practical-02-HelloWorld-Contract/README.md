# Practical 2 — Writing and Deploying a Basic Smart Contract on Ethereum

## Aim
Write a simple Solidity smart contract and deploy it to a local Ethereum blockchain (Ganache) using Truffle.

## Prerequisites
- Ganache running (Quickstart Ethereum) — RPC Server `http://127.0.0.1:7545`
- Truffle installed (`npm install -g truffle`)

## Project Structure
```
Practical-02-HelloWorld-Contract/
├── contracts/
│   └── HelloWorld.sol
├── migrations/
│   └── 2_deploy_contracts.js
└── truffle-config.js
```

## Steps

**1. Initialize a Truffle project** (if starting fresh)
```bash
truffle init
```

**2. Write the contract** — [`contracts/HelloWorld.sol`](contracts/HelloWorld.sol)
```solidity
// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

contract HelloWorld {
    string public message = "Hello Blockchain";
}
```

**3. Write the migration** — [`migrations/2_deploy_contracts.js`](migrations/2_deploy_contracts.js)
```js
const HelloWorld = artifacts.require("HelloWorld");

module.exports = function (deployer) {
  deployer.deploy(HelloWorld);
};
```

**4. Configure Truffle to point at Ganache** — [`truffle-config.js`](truffle-config.js)
```js
module.exports = {
  networks: {
    development: {
      host: "127.0.0.1",
      port: 7545,
      network_id: "*"
    }
  },
  compilers: {
    solc: {
      version: "0.8.19"
    }
  }
};
```

**5. Compile**
```bash
truffle compile
```

**6. Deploy to Ganache**
```bash
truffle migrate
```
Check Ganache — you should see a new transaction and a new block.

**7. Interact via the Truffle console**
```bash
truffle console
```
```js
let instance = await HelloWorld.deployed()
let msg = await instance.message()
msg.toString()
```

### Expected Output
```
Hello Blockchain
```

## Note on this file vs. the original journal
The journal's `truffle-config.js` snippet was cut off mid-file (the `compilers` block wasn't closed). The version above is the complete, working version — copy this one, not a partial snippet.
