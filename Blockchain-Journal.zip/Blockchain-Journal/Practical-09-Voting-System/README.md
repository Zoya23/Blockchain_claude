# Practical 9 — Implementing a Secure Voting System Using Blockchain

## Aim
Build a Solidity contract that lets each Ethereum address vote once for a candidate, with duplicate-vote prevention.

## ⚠️ Note on this file
Your journal describes this contract's required pieces (candidate structure, candidate storage, voter tracking, duplicate-vote prevention, a constructor that creates "Alice" and "Bob") and shows the **console commands and expected outputs**, but the actual Solidity source was never pasted into the journal text. [`contracts/VotingSystem.sol`](contracts/VotingSystem.sol) below is written to match that description **and** produce the exact console behavior shown in your journal (including the `"You have already voted"` error text) — double check it against your instructor's reference if one was given.

## Project Structure
```
Practical-09-Voting-System/
├── contracts/
│   └── VotingSystem.sol
├── migrations/
│   └── 2_deploy_voting.js
└── truffle-config.js
```

## Contract — [`contracts/VotingSystem.sol`](contracts/VotingSystem.sol)
- `Candidate` struct: `id`, `name`, `voteCount`
- `candidates` — public mapping, auto-seeded with **Alice** (id 1) and **Bob** (id 2) in the constructor
- `voters` — mapping tracking which addresses have already voted
- `vote(candidateId)` — reverts with `"You have already voted"` if `voters[msg.sender]` is already `true`; otherwise marks the sender as voted and increments the candidate's `voteCount`

## Steps
1. Ganache → Quickstart Ethereum
2. `truffle init` in folder `BlockchainVotingSystem`
3. Add the contract, migration, and config from this folder
4. `truffle compile`
5. `truffle migrate --reset`
6. `truffle console`

### Truffle console session
```js
let voting = await VotingSystem.deployed()

// Check candidates
await voting.candidates(1)   // Alice
await voting.candidates(2)   // Bob

// Get Ganache accounts
let accounts = await web3.eth.getAccounts()

// Cast votes
await voting.vote(1, { from: accounts[1] })   // vote Alice
await voting.vote(2, { from: accounts[2] })   // vote Bob

// Verify vote counts
let result1 = await voting.candidates(1)
result1.voteCount.toString()   // "1"

let result2 = await voting.candidates(2)
result2.voteCount.toString()   // "1"

// Test duplicate voting
await voting.vote(1, { from: accounts[1] })
// Expected: Error — "You have already voted"
```
