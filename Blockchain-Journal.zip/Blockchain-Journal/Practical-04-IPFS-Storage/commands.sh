#!/bin/bash
# Practical 4 — Storing and Retrieving Data using IPFS

# Step 1: Verify IPFS is installed (IPFS Desktop or CLI)
ipfs --version

# Step 2: Initialize the IPFS node (creates identity, config, local repo)
ipfs init

# Step 3: Start the IPFS daemon
ipfs daemon
# Output: "Daemon is ready" — leave this running in its own terminal

# Step 4: Create a sample data file
echo "Blockchain data stored using IPFS" > data.txt

# Step 5: Add the file to IPFS (run in a new terminal)
ipfs add data.txt
# Output: added <CID> data.txt
# The returned value is the IPFS CID (Content Identifier), e.g. QmXyz123abc

# Step 6: Retrieve the data using its CID
ipfs cat <CID>
# Output: Blockchain data stored using IPFS

# Step 7: Download the file from the IPFS network
ipfs get <CID>

# Step 8: List locally stored IPFS objects
ipfs refs local

# Step 9: Pin the data so it isn't garbage-collected
ipfs pin add <CID>
