# Practical 4 — Storing and Retrieving Data using IPFS

## Aim
Store a file on IPFS (InterPlanetary File System), retrieve it via its content hash, and demonstrate tamper detection.

## Steps
See [`commands.sh`](commands.sh) for the full copy-pasteable sequence:

1. Install IPFS Desktop, verify with `ipfs --version`
2. `ipfs init` — creates node identity, config, local repo
3. `ipfs daemon` — starts the node (leave running)
4. Create `data.txt` with sample content
5. `ipfs add data.txt` → returns a **CID** (Content Identifier), e.g. `QmXyz123abc`
6. `ipfs cat <CID>` — retrieve the file's contents by CID
7. `ipfs get <CID>` — download the file locally
8. `ipfs refs local` — list locally stored object hashes
9. `ipfs pin add <CID>` — pin the data so it isn't garbage-collected

## Code / Concept Explanation
| Concept | Meaning |
|---|---|
| **IPFS add** | Stores the file into IPFS and generates a unique CID |
| **CID** | Content-addressed identifier — acts as the file's address on IPFS |
| **IPFS cat** | Retrieves data using its CID |
| **Hash verification** | If the file's data changes, its CID changes too — this is how tampering is detected |

### Expected Output
```
$ ipfs add data.txt
added QmXyz123abc data.txt

$ ipfs cat QmXyz123abc
Blockchain data stored using IPFS
```

No corrections needed — this practical's commands are correct as written in the journal.
