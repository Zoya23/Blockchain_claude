# Practical 6 — Implementing a Blockchain-Based Data Provenance System

## Aim
Track the history/ownership ("provenance") of a patient record across multiple parties using a simple hash-linked blockchain, and detect if a past record is tampered with.

## File
[`data_provenance.py`](data_provenance.py)

## Run
```bash
python data_provenance.py
```

## What it does
- `Block` stores `data`, `owner`, `timestamp`, `previous_hash`, a `data_hash` (hash of just the data) and a `block_hash` (hash of the whole block, chaining to the previous block's hash)
- `Blockchain` creates a genesis block, then appends new blocks via `add_block(data, owner)`
- `display_chain()` prints every block's details
- `verify_chain()` checks two things for every block after the genesis block:
  1. Its `previous_hash` matches the prior block's `block_hash` (chain link intact)
  2. Its `data_hash` still matches a fresh hash of its current `data` (data unmodified)
- The demo simulates 3 record updates (Dr. Sharma → Dr. Mehta → Hospital Admin), then **directly mutates** `chain[1].data` to simulate tampering, and re-verifies

### Verified Output
```
Warning! Data Provenance Chain Tampered
```
(because `chain[1].data` was changed after block creation, so `data_hash` no longer matches)

✅ Ran end-to-end — logic and output match the journal exactly. No changes needed.
