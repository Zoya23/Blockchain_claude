import hashlib
import datetime


class Block:
    def __init__(self, index, data, owner, previous_hash):
        self.index = index
        self.data = data
        self.owner = owner
        self.timestamp = str(datetime.datetime.now())
        self.previous_hash = previous_hash
        self.data_hash = self.generate_data_hash()
        self.block_hash = self.generate_block_hash()

    def generate_data_hash(self):
        return hashlib.sha256(self.data.encode()).hexdigest()

    def generate_block_hash(self):
        block_content = (
            str(self.index)
            + self.data
            + self.owner
            + self.timestamp
            + self.previous_hash
            + self.data_hash
        )
        return hashlib.sha256(block_content.encode()).hexdigest()


class Blockchain:
    def __init__(self):
        self.chain = []
        self.create_genesis_block()

    def create_genesis_block(self):
        genesis_block = Block(
            0,
            "Genesis Block",
            "System",
            "0"
        )
        self.chain.append(genesis_block)

    def add_block(self, data, owner):
        previous_block = self.chain[-1]
        new_block = Block(
            len(self.chain),
            data,
            owner,
            previous_block.block_hash
        )
        self.chain.append(new_block)

    def display_chain(self):
        for block in self.chain:
            print("\n--------------------------------")
            print("Block Number:", block.index)
            print("Data:", block.data)
            print("Owner:", block.owner)
            print("Timestamp:", block.timestamp)
            print("Data Hash:", block.data_hash)
            print("Previous Hash:", block.previous_hash)
            print("Block Hash:", block.block_hash)

    def verify_chain(self):
        for i in range(1, len(self.chain)):
            current = self.chain[i]
            previous = self.chain[i - 1]
            if current.previous_hash != previous.block_hash:
                return False
            if current.data_hash != current.generate_data_hash():
                return False
        return True


provenance_chain = Blockchain()

provenance_chain.add_block(
    "Patient Record: Name=Riya, Disease=Fever, Medicine=Paracetamol",
    "Dr. Sharma"
)

provenance_chain.add_block(
    "Patient Record Updated: Disease=Viral Fever, Medicine=Paracetamol",
    "Dr. Mehta"
)

provenance_chain.add_block(
    "Record Shared with Insurance Department",
    "Hospital Admin"
)

provenance_chain.display_chain()

provenance_chain.chain[1].data = "Patient Record: Name=Riya, Disease=Covid, Medicine=Antiviral"

if provenance_chain.verify_chain():
    print("\nBlockchain Provenance Verified Successfully")
else:
    print("\nWarning! Data Provenance Chain Tampered")
